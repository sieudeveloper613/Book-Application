package com.example.mob2041_pnlib_libmana_project.Model;

public class TopBook {
    public String Book;
    public int Mount;
}
