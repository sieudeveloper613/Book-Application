package com.example.mob2041_pnlib_libmana_project.Model;

public class ThanhVien {
    public int maTV;
    public String hoTen;
    public String namSinh;


}
