package com.example.mob2041_pnlib_libmana_project.Model;

public class Sach {
    public int maSach;
    public String tenSach;
    public int giaThue;
    public int maLoai;
}
