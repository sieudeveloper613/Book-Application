package com.example.mob2041_pnlib_libmana_project.Model;

public class LoaiSach {
    public int maLoai;
    public String tenLoai;
}
