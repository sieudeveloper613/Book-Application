package com.example.mob2041_pnlib_libmana_project.Model;

import java.util.Date;

public class PhieuMuon {
    public int maPM;
    public String maTT;
    public int maTV;
    public int maSach;
    public int tienThue;
    public int traSach;
    public Date ngay;
}
